
import NewsletterForm from '../components/NewsletterForm';

export default function Home() {
  return (
    <div className="max-w-md mx-auto mt-10 p-6 border rounded">
      <h1 className="text-xl font-bold mb-4">Join Our Newsletter</h1>
      <NewsletterForm />
    </div>
  );
}

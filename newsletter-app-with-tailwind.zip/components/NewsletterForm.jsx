
import { useState } from 'react';

export default function NewsletterForm() {
  const [formData, setFormData] = useState({ name: '', email: '' });
  const [status, setStatus] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setStatus('Submitting...');

    const res = await fetch('/api/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const result = await res.json();
    setStatus(result.message);
    if (res.ok) setFormData({ name: '', email: '' });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <input type="text" name="name" placeholder="Your name" value={formData.name} onChange={handleChange} required className="border p-2 w-full" />
      <input type="email" name="email" placeholder="Your email" value={formData.email} onChange={handleChange} required className="border p-2 w-full" />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2">Subscribe</button>
      {status && <p className="text-sm mt-2">{status}</p>}
    </form>
  );
}

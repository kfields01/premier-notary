
# 📬 Newsletter Signup App (React + Vercel + Google Sheets + Tailwind)

This project allows users to subscribe to a newsletter using their name and email address. Submissions are stored in a Google Sheet via a secure serverless function hosted on Vercel.

## 🚀 Getting Started

1. Clone the repo and run `npm install`
2. Add your credentials to `.env.local`
3. Run `npm run dev` to start locally
4. Deploy to Vercel or another platform

## 🛠 Environment Variables

- `GOOGLE_SERVICE_ACCOUNT_EMAIL`
- `GOOGLE_PRIVATE_KEY`
- `GOOGLE_SHEET_ID`
